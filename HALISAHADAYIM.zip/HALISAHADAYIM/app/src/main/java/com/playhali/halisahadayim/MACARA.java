package com.playhali.halisahadayim;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.playhali.halisahadayim.Bilgi;

import java.util.ArrayList;

public class MACARA extends AppCompatActivity {
DatabaseReference mDatabaseReference;
EditText searchView,searchView2;
RecyclerView recyclerView;
FirebaseUser firebaseUser;
ArrayList<String> ilfulList;
ArrayList<String> ilcefulList;
ArrayList<String> mevkifulList;
SearchAdapter searchAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_macara);
       recyclerView = findViewById(R.id.recylerView);
        searchView = findViewById(R.id.searchView);
        searchView2 = findViewById(R.id.searchView2);
        mDatabaseReference = FirebaseDatabase.getInstance().getReference();
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();


        ilfulList = new ArrayList<>();
        ilcefulList = new ArrayList<>();
        mevkifulList = new ArrayList<>();

        recyclerView.hasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(this,LinearLayoutManager.VERTICAL));
        searchView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                if(!s.toString().isEmpty()){

                    setAdapter(s.toString());

                } else {
                    ilfulList.clear();
                    ilcefulList.clear();
                    mevkifulList.clear();
                    recyclerView.removeAllViews();
                }

            }

        });






    }

    private void setAdapter(final String searchedString) {


        mDatabaseReference.child("Bilgiler").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ilfulList.clear();
                ilcefulList.clear();
                mevkifulList.clear();
                recyclerView.removeAllViews();

                int counter = 0;
                for(DataSnapshot snapshot:dataSnapshot.getChildren()){
                    String vid=snapshot.getKey();
                    String il= snapshot.child("il").getValue(String.class);
                    String ilce= snapshot.child("ilce").getValue(String.class);
                    String mevki= snapshot.child("mevki").getValue(String.class);

                    if(il.toLowerCase().contains(searchedString.toLowerCase())){
                        ilfulList.add(il);
                        ilcefulList.add(ilce);
                        mevkifulList.add(mevki);
                        counter++;



                    }else if (ilce.toLowerCase().contains(searchedString.toLowerCase())){
                        ilfulList.add(il);
                        ilcefulList.add(ilce);
                        mevkifulList.add(mevki);
                        counter++;


                    }
                    if(counter==15){
                        break;
                    }
                 searchAdapter = new SearchAdapter(MACARA.this,ilfulList,ilcefulList,mevkifulList);
                    recyclerView.setAdapter(searchAdapter);


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}
