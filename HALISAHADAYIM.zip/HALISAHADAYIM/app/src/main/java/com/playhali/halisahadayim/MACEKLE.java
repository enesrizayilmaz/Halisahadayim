package com.playhali.halisahadayim;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class MACEKLE extends AppCompatActivity {
    Spinner spinner1, spinner2;
    EditText editText5;
    EditText editText6;
    EditText editText7;
    EditText editText8;
    String editText5x;
    String editText6x;
    String editText7x;
    String editText8x;
    String editText9x;
    String editText10x;
    com.playhali.halisahadayim.Bilgi bilgi;

    DatabaseReference reference;
    int maxid = 0;
    DatabaseReference databaseReference;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.macekle);
        database=FirebaseDatabase.getInstance();
        bilgi= new Bilgi();

        spinner1 = findViewById(R.id.spinner1);

        spinner2 = findViewById(R.id.spinner2);
        editText5 = findViewById(R.id.editText5);
        editText6 = findViewById(R.id.editText6);
        editText7 = findViewById(R.id.editText7);
        editText8 = findViewById(R.id.editText8);
        editText5x=editText5.getText().toString();
        editText6x=editText6.getText().toString();
        editText7x=editText7.getText().toString();
        editText8x=editText8.getText().toString();




        List<String> iller = new ArrayList<>();
        iller.add(0, "İl seçiniz");
        iller.add("january");
        iller.add("january");
        iller.add("january");
        iller.add("january");
        iller.add("january");
        iller.add("january");
        iller.add("january");
        iller.add("january");
        iller.add("january");
        iller.add("january");
        iller.add("january");
        ArrayAdapter<String> adapter;

        adapter = new ArrayAdapter(this, R.layout.spinner_item,iller);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        final String Il[] = getResources().getStringArray(R.array.IL);
        final String Adana[] = getResources().getStringArray(R.array.Adana);
        final String Adıyaman[] = getResources().getStringArray(R.array.Adıyaman);
        final String Afyon[] = getResources().getStringArray(R.array.Afyon);


        spinner1.setAdapter(adapter);

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (adapterView.getItemAtPosition(i).equals("choose event")) {

                } else {
                    String item = adapterView.getItemAtPosition(i).toString();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (adapterView.getItemAtPosition(i).equals("choose event")) {

                } else {
                    String item = adapterView.getItemAtPosition(i).toString();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override

            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {

                if (position == 1) {
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(MACEKLE.this, R.layout.spinner_item, Adana);

                    spinner2.setAdapter(adapter2);
                    adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


                }
                if (position == 2) {
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(MACEKLE.this, R.layout.spinner_item, Adıyaman);
                    spinner2.setAdapter(adapter2);
                    adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }
                if (position == 3) {
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(MACEKLE.this, R.layout.spinner_item, Afyon);
                    spinner2.setAdapter(adapter2);
                    adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }
    private void getValues(){
        bilgi.setIl(spinner1.getSelectedItem().toString());
        bilgi.setIlce(spinner2.getSelectedItem().toString());
        bilgi.setTelno(editText5.getText().toString());
        bilgi.setSaat(editText6.getText().toString());
        bilgi.setTarih(editText7.getText().toString());
        bilgi.setMevki(editText8.getText().toString());
        databaseReference = database.getReference("Bilgiler");
        String key = databaseReference.push().getKey();
        DatabaseReference trabzon= database.getReference("Bilgiler/"+key);
        trabzon.setValue(bilgi);

    }


    public void btnAddData(View view) {





        getValues();

        Toast.makeText(MACEKLE.this,"Maç kaydedildi.",Toast.LENGTH_SHORT).show();




    }
}