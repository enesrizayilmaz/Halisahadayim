package com.playhali.halisahadayim;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class GİRİSMENU extends AppCompatActivity {
    public Button button11;

    public Button button13;
    public Button button6;
    public Button button7;
    public Button button8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_girismenu);
        button11 = findViewById(R.id.button11);
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent kadrokur = new Intent(GİRİSMENU.this, KADROKUR.class);
                startActivity(kadrokur);
            }
        }

        );


        button13 = findViewById(R.id.button63);
        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent adambul = new Intent(GİRİSMENU.this, OYUNCUBUL.class);
                startActivity(adambul);
            }
        }

        );
        button6 = findViewById(R.id.button64);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent adambul = new Intent(GİRİSMENU.this, OYUNCUEKLE.class);
                startActivity(adambul);
            }
        });
        button7 = findViewById(R.id.button61);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent adambul = new Intent(GİRİSMENU.this, MACEKLE.class);
                startActivity(adambul);
            }
        }

        );
        button8 = findViewById(R.id.button62);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent adambul = new Intent(GİRİSMENU.this, MACARA.class);
                startActivity(adambul);
            }
        }

        );


    }
}